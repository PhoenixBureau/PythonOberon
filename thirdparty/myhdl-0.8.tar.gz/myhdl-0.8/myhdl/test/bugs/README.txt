Requirements:
  * cver, icarus, GHDL or vlog/vcom (default)
  * py.test

See the Makefile - it contains targets per simulator. 
