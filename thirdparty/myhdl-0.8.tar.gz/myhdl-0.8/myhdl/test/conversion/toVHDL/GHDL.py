from myhdl.conversion import verify

verify.simulator = "GHDL"
