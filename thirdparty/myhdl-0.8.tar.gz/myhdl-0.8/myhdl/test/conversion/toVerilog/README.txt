Original tests for conversion to Verilog
----------------------------------------

Requirements:
  * cver or icarus 
  * co-simulation with the target simulator enabled  

icarus is setup by default. You can change that by going into util.py
and using the cver definitions for the functions setupCosimulation
and verilogCompile.

