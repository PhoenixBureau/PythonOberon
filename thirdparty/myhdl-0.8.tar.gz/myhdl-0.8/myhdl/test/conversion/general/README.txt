Conversion tests that should work with both VHDL and Verilog
------------------------------------------------------------

Requirements:
  * cver, icarus, GHDL, or vcom/vlog (default)
  * py.test

See the Makefile - it contains targets per simulator. 
